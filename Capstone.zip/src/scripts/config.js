const CONFIG = {
  BASE_URL: 'https://backend-stunting.onrender.com',
};

export default CONFIG;
